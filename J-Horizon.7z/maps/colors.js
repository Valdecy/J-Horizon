
	var colors = 
	[
	"black",
	"red",
    "green",
	"blue",
	"yellow",
	"orange",
	"blueviolet",
	"goldenrod",
	"dimgray",
	"indianred",
    "white",
	"springgreen",
	"mediumorchid",
	"maroon",
	"teal",
	"orangered",
	"magenta"
	];