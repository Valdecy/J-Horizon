var xy_depots = 
	[
	  [0, 0, "# DT-0 #"]
	];