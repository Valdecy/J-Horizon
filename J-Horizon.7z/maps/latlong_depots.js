var latlong_depots = 
	[
	  [-22.781578, -41.9001036, "# DT-0 #"]
	];