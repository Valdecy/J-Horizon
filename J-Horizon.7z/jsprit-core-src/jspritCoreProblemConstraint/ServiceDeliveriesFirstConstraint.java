/*
 * Licensed to GraphHopper GmbH under one or more contributor
 * license agreements. See the NOTICE file distributed with this work for
 * additional information regarding copyright ownership.
 *
 * GraphHopper GmbH licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package jspritCoreProblemConstraint;

import jspritCoreProblemMisc.JobInsertionContext;
import jspritCoreProblemSolutionRouteActivity.DeliverService;
import jspritCoreProblemSolutionRouteActivity.DeliverShipment;
import jspritCoreProblemSolutionRouteActivity.PickupService;
import jspritCoreProblemSolutionRouteActivity.PickupShipment;
import jspritCoreProblemSolutionRouteActivity.ServiceActivity;
import jspritCoreProblemSolutionRouteActivity.TourActivity;

public class ServiceDeliveriesFirstConstraint implements HardActivityConstraint {

    @Override
    public ConstraintsStatus fulfilled(JobInsertionContext iFacts, TourActivity prevAct, TourActivity newAct, TourActivity nextAct, double prevActDepTime) {
        if (newAct instanceof PickupService && nextAct instanceof DeliverService) {
            return ConstraintsStatus.NOT_FULFILLED;
        }
        if (newAct instanceof ServiceActivity && nextAct instanceof DeliverService) {
            return ConstraintsStatus.NOT_FULFILLED;
        }
        if (newAct instanceof DeliverService && prevAct instanceof PickupService) {
            return ConstraintsStatus.NOT_FULFILLED_BREAK;
        }
        if (newAct instanceof DeliverService && prevAct instanceof ServiceActivity) {
            return ConstraintsStatus.NOT_FULFILLED_BREAK;
        }

        if (newAct instanceof DeliverService && prevAct instanceof PickupShipment) {
            return ConstraintsStatus.NOT_FULFILLED_BREAK;
        }
        if (newAct instanceof DeliverService && prevAct instanceof DeliverShipment) {
            return ConstraintsStatus.NOT_FULFILLED_BREAK;
        }
        if (newAct instanceof PickupShipment && nextAct instanceof DeliverService) {
            return ConstraintsStatus.NOT_FULFILLED;
        }
        if (newAct instanceof DeliverShipment && nextAct instanceof DeliverService) {
            return ConstraintsStatus.NOT_FULFILLED;
        }

        return ConstraintsStatus.FULFILLED;
    }

}
